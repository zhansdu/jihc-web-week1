document.getElementById("form1").addEventListener("submit", function (e) {
  e.preventDefault();

  var name = document.getElementById("name1").value;
  var email = document.getElementById("email1").value;
  var pass = document.getElementById("pass1").value;

  if (findUser(email)) {
    alert("Такой email уже зарегистрирован");
    return;
  }

  var arr = getUsers();
  arr.push({ name: name, email: email, pass: pass });
  setUsers(arr);

  this.reset();

  var m = new bootstrap.Modal(document.getElementById("modal2"));
  m.show();
});

document.getElementById("form2").addEventListener("submit", function (e) {
  e.preventDefault();

  var email = document.getElementById("email2").value;
  var pass = document.getElementById("pass2").value;
  var user = findUser(email);

  if (user && user.pass == pass) {
    alert("Привет, " + user.name + "!");
  } else {
    alert("Неверный email или пароль");
  }

  this.reset();
});
