function nav() {
  document.getElementById("navbar").innerHTML = `
    <nav class="navbar navbar-expand-md navbar-dark bg-dark sticky-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">Global Bound</a>
        <div class="navbar-nav">
          <a class="nav-link" href="index.html">Home</a>
          <a class="nav-link" href="auth.html">Register / Login</a>
          <a class="nav-link" href="members.html">Members</a>
          <a class="nav-link" href="blank.html">Blank</a>
        </div>
      </div>
    </nav>`;
}

function foot() {
  document.getElementById("footer").innerHTML = `
    <footer class="bg-dark text-light text-center py-3">
      Global Bound &copy; 2026
    </footer>`;
}

document.addEventListener("DOMContentLoaded", function () {
  nav();
  foot();
});

function getUsers() {
  return JSON.parse(localStorage.getItem("users")) || [];
}

function setUsers(arr) {
  localStorage.setItem("users", JSON.stringify(arr));
}

function findUser(mail) {
  var arr = getUsers();
  for (var i = 0; i < arr.length; i++) {
    if (arr[i].email == mail) {
      return arr[i];
    }
  }
  return null;
}
