function showTable() {
  var arr = getUsers();
  var tbody = document.getElementById("tbody1");

  tbody.innerHTML = "";
  for (var i = 0; i < arr.length; i++) {
    tbody.innerHTML += "<tr><td>" + arr[i].name + "</td><td>" + arr[i].email + "</td></tr>";
  }
}

document.addEventListener("DOMContentLoaded", showTable);
